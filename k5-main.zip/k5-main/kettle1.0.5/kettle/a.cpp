#include <iostream>
#include <fstream>
#include <string>
#include <variant>
using namespace std;
int main(){
auto hi="hi";

for ( int ttt=0; ttt <= 10; ttt++) { 
cout << hi << endl;
}
return 0;














}