#include <iostream>
#include <fstream>
#include <string>
using namespace std;
int main(){
for ( int ttt=0; ttt <= 10; ttt++) { 
cout << "hi" << endl;
}
return 0;














}